
import QtQuick 2.6
import QtQuick.Controls 1.4
import QtQuick.Controls.Styles 1.4
import QtQuick.Controls 2.0 as C2
import QtQuick 2.7
import QtSensors 5.2

Row {

    Register {
            id: firstWindow


            // Обработчик сигнала на открытие основного окна
            onSignalExit: {
                firstWindow.close()     // Закрываем первое окно
                mainWindow.show()       // Показываем основное окно
            }
        }
    id: containerRow

    Item{

        id:dataModel
        property bool weatherAvailable:false
        property bool weatherFromCache:false

        property var weatherData:[]
    }
    function setModelData(weatherAvailable, weatherForCity, weatherDate, weatherTemp, weatherCondition, weatherIconUrl, weatherFromCache) {

        dataModel.weatherData = {

               'weatherForCity': weatherForCity,

               'weatherDate': weatherDate,

               'weatherTemp': weatherTemp,

               'weatherCondition': weatherCondition,

               'weatherIconUrl': weatherIconUrl

               }

        dataModel.weatherAvailable = weatherAvailable

        dataModel.weatherFromCache = weatherFromCache

    }
    function updateFromJson(parsedWeatherJson) {

       // Use the new parsed JSON file to update the model and the cache

       setModelData(true,

                    parsedWeatherJson.name + ", " + parsedWeatherJson.sys.country,

                    new Date(),

                    parsedWeatherJson.main.temp,

                    parsedWeatherJson.weather[0].main,

                    "http://openweathermap.org/img/w/" + parsedWeatherJson.weather[0].icon + ".png",

                    false)

    }
    property var mapSource
    property real fontSize : 14
    property color labelBackground : "black"
    property int edge: Qt.RightEdge
    property alias expanded: sliderToggler.checked


    function rightEdge() {
        return (containerRow.edge === Qt.RightEdge);
    }



    Column {

        Item {
            id: sceneItem
            property variant sceneSize


                sceneSize: sceneItem.sceneSize

                clip: true

                x: Math.floor(scaledBounds.x * sceneItem.width)
                y: Math.floor(scaledBounds.y * sceneItem.height)
                //anchors.horizontalCenter: parent.horizontalCenter

                //AttitudeActual.Yaw is converted to -180..180 range
                property real yaw : (AttitudeActual.Yaw+180+720) % 360 - 180

                //split compass band to 8 parts to ensure it doesn't exceed the max texture size
                Row {
                    id: compass_band_composed
                    anchors.centerIn: parent
                    //the band is 540 degrees wide
                    anchors.horizontalCenterOffset: -compass.yaw/540*width




                    visible: PositionActual.East != 0 || PositionActual.North != 0

                    property real bearing : Math.atan2(PositionActual.East, PositionActual.North)*180/Math.PI



                    property int activeWaypoint: WaypointActive.Index
                    onActiveWaypointChanged: qmlWidget.exportUAVOInstance("Waypoint", activeWaypoint)






                }
            }

        id: sliderColumns
        spacing: 0
        topPadding: 0
        bottomPadding: 0

            Rectangle{

                Label {
                    anchors.top:  parent.top
                    anchors.left: parent.left
                    Button {
                        id: sliderToggler
                        x: 10
                        y: 10

                        smooth: true  // smoother image
                        Image {
                                anchors.fill: parent
                                source: "../resources/Layers.png"
                                fillMode: Image.PreserveAspectFit
                            }
                            checkable: true
                            checked: true
                        text: ""
                        width: 50
                        height: 50


                        style: ButtonStyle {

                            background: Rectangle {

                               // color: "#669FBE"
                               // border.color: "#4898C3"
                                radius: 15

                            }
                        }

                    }
                    Button {
                        id: sliderToggler1
                        x: 350
                        y: 10

                        smooth: true  // smoother image
                        Image {
                                anchors.fill: parent
                                source: "../resources/Loopa.png"
                                fillMode: Image.PreserveAspectFit
                            }
                            checkable: true
                            checked: true
                        text: ""
                        width: 50
                        height: 50


                        style: ButtonStyle {

                            background: Rectangle {

                               // color: "#669FBE"
                                //border.color: "#4898C3"
                                radius: 15

                            }
                        }

                    }
                    Rectangle {
                        x:75
                        y:10
                        width: 260
                        height: 50
                       // color: "#DCEFEB"
                       // border.color: "#4898C3"

                        radius: 15

                        Image {
                                anchors.fill: parent
                                source: "../resources/topper.png"
                                fillMode: Image.PreserveAspectFit
                            }
                        TextInput {
                            id: input1
                            x: 20; y: 16
                            width: 120; height: 20
                            focus: true
                            font.pointSize: 10
                            color: "black"

                            text: "Поиск геоточки"
                        }
                        QtObject {
                            property var locale: Qt.locale()
                            property date currentTime: new Date()
                            property string timeString

                            Component.onCompleted: {
                                timeString = currentTime.toLocaleTimeString(locale, Locale.ShortFormat);
                                print(Date.fromLocaleTimeString(locale, timeString, Locale.ShortFormat));
                            }

                        }

                   }
                    Text {
                        y:60; x:20;
                        text:  new Date().toLocaleString(Qt.locale("Moscow"))
                    }
                   // Rectangle {
                     //   x:0
                       // y:740
                   //     width: 412
                     //   height: 100
                   //     color: "#DCEFEB"
                     //   border.color: "#4898C3"

                       // radius: 0
                       // Image {
                         //       anchors.fill: parent
                       //         source: "../resources/weather_wind.png"
                        //        fillMode: Image.fill
                        //    }


                  // }
                }

                Label {

                    Button {
                        id: plusButton
                        x: 350
                        y: 340
                        smooth: true  // smoother image
                        Image {
                                anchors.fill: parent
                                source: "../resources/plus.png"
                                fillMode: Image.fill
                            }
                            checkable: true
                            checked: true
                        width: 50
                        height: 50
                        text: "+"
                        onClicked: containerRow.mapSource.zoomLevel += 1
                        style: ButtonStyle {

                            background: Rectangle {


                                border.color: "#4898C3"
                                radius: 15
                                color: "#79b0ce"
                            }
                        }

                    }
                    Button {
                        id: minusButton
                        x: 350
                        y: 410
                        smooth: true  // smoother image

                        Image {
                                anchors.fill: parent
                                source: "../resources/minus.png"
                                fillMode: Image.fill
                            }
                            checkable: true
                            checked: true
                        width: 50
                        height: 50
                        text: "-"
                        onClicked: containerRow.mapSource.zoomLevel -= 1
                        style: ButtonStyle {


                            background: Rectangle {


                                border.color: "#4898C3"
                                radius: 15
                                color: "#79b0ce"
                            }
                        }

                    }

                }

            }

            }







    Rectangle {

        id: sliderContainer
        height: parent.height
        width: sliderRow.width
        visible: sliderToggler.checked
        color: Qt.rgba( 0, 191 / 255.0, 255 / 255.0, 0.07)

        property var labelBorderColor: "black"
        property var slidersHeight : sliderContainer.height
                                     - rowSliderValues.height
                                     - rowSliderLabels.height
                                     - sliderColumn.spacing
                                     - sliderColumn.topPadding
                                     - sliderColumn.bottomPadding

        Column {
            id: sliderColumn
            spacing: 0
            topPadding: 0
            bottomPadding: 0
            anchors.centerIn: parent

            // the sliders value labels
            Row {
                id: rowSliderValues
                width: 0
                height: 0
                property real entryWidth: zoomSlider.width



                Rectangle{
                    color: labelBackground
                    height: parent.height
                    width: parent.Width
                    border.color: sliderContainer.labelBorderColor
                    Label {
                        anchors.left: parent.left
                        anchors.bottom: parent.bottom



                        Button {
                            id: vаfButton
                            x: 10
                            y: 70
                            smooth: true  // smoother image

                                checkable: true
                                checked: true
                            style: ButtonStyle {

                               background: Rectangle {
                                   Image {
                                          // anchors.fill: parent
                                        x:-4
                                           source: "../resources/Pos.png"
                                           fillMode: Image.PreserveAspectFit
                                           opacity: 0.9
                                       }

                                    //border.color: "#4898C3"
                                    radius: 15
                                    //color: "#79b0ce"
                                }
                            }

                            width: 50
                            height: 50

                            text: ""
                            onClicked:  containerRow.mapSource.bearing = 0
                        }
                        Button {
                            id: zаfButton
                            x: 10
                            y: 0
                            smooth: true  // smoother image

                                checkable: true
                                checked: true
                            style: ButtonStyle {

                                background: Rectangle {

                                    Image {
                                            x:-4
                                            source: "../resources/Comp.png"
                                            fillMode: Image.PreserveAspectFit
                                            opacity: 0.8
                                        }

                                   // border.color: "#4898C3"
                                    radius: 15
                                   // color: "#79b0ce"
                                }
                            }


                            width: 50
                            height: 50
                            text: ""
                            onClicked:  containerRow.mapSource.bearing = 0
                        }
                        Button {
                            id: zzvаfButton
                            x: 10
                            y: 350
                            smooth: true  // smoother image
                            Image {
                                    anchors.fill: parent
                                    source: "../resources/layers.svg"
                                    fillMode: Image.PreserveAspectFit
                                }
                                checkable: true
                                checked: true
                            width: 50
                            height: 50




                            onClicked: containerRow.mapSource.zoomLevel -= 1
                        }
                        Button {
                            id: vvvzаfButton
                            x: 10
                            y: -140
                            smooth: true  // smoother image

                                checkable: true
                                checked: true
                            style: ButtonStyle {
                                background: Rectangle {
                                    Image {
                                            x:-4
                                            source: "../resources/Prof.png"
                                            fillMode: Image.Fill
                                        }

                                    //border.color: "#4898C3"
                                    radius: 15
                                  //  color: "#79b0ce"
                                }


                            }

                            onClicked:  {
                                firstWindow.show() // Открываем второе окно
                                mainWindow.hide()
                            }
                            width: 50
                            height: 50
                            text: ""

                        }
                        Button {
                            id: jjzаfButton
                            x: 10
                            y: -70
                            smooth: true  // smoother image

                                checkable: true
                                checked: true

                            style: ButtonStyle {

                                background: Rectangle {


                                  //  border.color: "#4898C3"
                                    radius: 15
                                   // color: "#79b0ce"
                                    Image {
                                            x:-4
                                            source: "../resources/Setting.png"
                                            fillMode: Image.fill

                                        }
                                }
                            }

                            width: 50
                            height: 50
                            text: ""

                        }

                    }

                }


                }


            }


        }

    Item {
        id: widget




        clip: true
        visible: true

        property string type: "widget"
        property bool autoStart: true
        property bool loaded: false
        property bool started: false

        // load all data before we and our children are visible
        function preload() {
            if (this.scenePreload == undefined) {
                for (var i=0; i<widget.children.length; i++) {
                    console.log("preload " + widget.children[i].type)
                    widget.children[i].scenePreload()
                }
            } else {
                console.log("preload " + widget.type)
                this.scenePreload()
            }

            loaded = true
        }

        // start presenting our data
        function start() {
            if (this.sceneStart == undefined) {
                for (var i=0; i<widget.children.length; i++) {
                    widget.children[i].started = true
                    console.log("start " + widget.children[i].type)
                    widget.children[i].sceneStart()
                }
            } else {
                console.log("start " + widget.type)
                this.sceneStart()
            }

            this.started = true
        }

        // pause presentation
        function pause() {
            if (this.scenePause == undefined) {
                for (var i=0; i<widget.children.length; i++) {
                    console.log("pause " + widget.children[i].type)
                    widget.children[i].scenePause()
                    widget.children[i].started = false
                }
            } else {
                console.log("pause " + widget.type)
                this.scenePause()
            }

            started = false
        }

        function isPausable() {
            var pausable = true
            if (this.sceneIsPausable == undefined) {
                for (var i=0; i<widget.children.length; i++) {
                    if (widget.children[i].sceneIsPausable != undefined) {
                        console.log("isPausable " + widget.children[i].type)
                        pausable = widget.children[i].sceneIsPausable()
                        if (pausable == false)
                            return false
                    }
                }
                return true
            } else {
                console.log("isPausable " + widget.type)
                return this.sceneIsPausable()
            }
        }

        function makeVisible() {

            this.visible = true
        }
    }



        anchors.fill: parent
        readonly property string apiUrl : "http://api.openweathermap.org/geo/1.0/direct?q="; //From https://openweathermap.org
        readonly property string weatherApiUrl : "https://api.openweathermap.org/data/2.5/weather?"; //From https://openweathermap.org
        readonly property string apiKey : "cf593c9428817b8024bd08ebb8d8ce21";
        readonly property string method : "GET";

        property double lon : 0.0;
        property double lat : 0.0;
        property string icon;
        property string main: "";
        property string description: " ";

        property double speed: 0.0;
        property double deg: 0.0;
        property double temp : 0.0;
        property double feels_like : 0.0;
        property double pressure : 0.0;
        property int humidity: 0;

        property bool isCelsius : unitType.checked ? true : false
        function dataRequest(type)
        {
            var req = new XMLHttpRequest();
            req.open(appObject.method, appObject.apiUrl + cityValue.text + "&limit=1&appid=" + appObject.apiKey);
            req.onreadystatechange = function() {
                if (req.readyState === XMLHttpRequest.DONE) {
                    let result = JSON.parse(req.responseText);
                    //Data
                    appObject.lat = JSON.stringify(result[0].lat);
                    appObject.lon = JSON.stringify(result[0].lon);
                    //Information
                    {
                        console.log("lat: " + JSON.stringify(result[0].lat))
                        console.log("lon: " + JSON.stringify(result[0].lon))
                    }
                    weatherRequest();
                }
            }
            req.onerror = function(){
                console.log("Error!")
            }
            req.send()
        }

        //! Remove extra double quote for some json outputs.
        function stringFixer(variable)
        {
            return variable.replace(/['"]+/g, '')
        }

        function weatherRequest()
        {
            var req = new XMLHttpRequest("https://api.open-meteo.com/v1/forecast?latitude=47.21&longitude=38.93&hourly=temperature_2m&timezone=Europe%2FMoscow");
            req.send()
            var unit = appObject.isCelsius ? "metric" : "imperial";
            req.open(appObject.method,"https://api.open-meteo.com/v1/forecast?latitude=47.21&longitude=38.93&hourly=temperature_2m&timezone=Europe%2FMoscow");
            req.onreadystatechange = function() {
                if (req.readyState === XMLHttpRequest.DONE) {
                    let result = JSON.parse(req.responseText);
                    appObject.icon          = JSON.stringify(result.weather[0].icon)
                    appObject.main          = JSON.stringify(result.weather[0].main)
                    appObject.description   = JSON.stringify(result.weather[0].description)
                    appObject.humidity      = JSON.stringify(result.main.humidity)
                    appObject.feels_like    = JSON.stringify(result.main.feels_like)
                    appObject.pressure      = JSON.stringify(result.main.pressure)
                    appObject.temp          = JSON.stringify(result.main.temp)
                    appObject.speed         = JSON.stringify(result.wind.speed)
                    appObject.deg           = JSON.stringify(result.wind.deg)

                    var icon = "qrc:/resources/icons/";
                    icon+= appObject.icon;
                    icon+="@2x.png";
                    iconImage.source = icon.replace(/['"]+/g, '');
                    busyIndicator.running = false;
                }
            }
            req.onerror = function(){
                console.log("Error!")
            }

        }
        property var parameters: undefined
        property double latitude: 52.3738
        property double longitude: 4.8910

        function getJson(latitude, longitude) {
            var xmlhttp = new XMLHttpRequest()
            var url = "https://api.open-meteo.com/v1/forecast?latitude=" + latitude
                    + "&longitude=" + longitude + "&hourly=temperature_2m,relativehumidity_2m,apparent_temperature,weathercode,windspeed_10m,winddirection_10m&daily=weathercode,temperature_2m_max,temperature_2m_min,sunrise,sunset&current_weather=true&timezone=Europe%2FAmsterdam"

            xmlhttp.onreadystatechange = function () {
                if (xmlhttp.readyState === XMLHttpRequest.DONE
                        && xmlhttp.status == 200) {
                    Row.parameters = JSON.parse(xmlhttp.responseText)
                }
            }

            xmlhttp.open("GET", url, true)
            xmlhttp.send()
        }
        Button {
            id: refreshButton
            anchors.bottom: parent.bottom
            anchors.left: parent.left

            text: "Update Weather"

            onClicked: getJson(Row.latitude, Row.longitude)
        }
onParametersChanged: console.log(Row.parameters['current_weather']['weathercode'])
        Image {

            width: parent.width*0.75 + 20
            height: parent.height*0.75 + 20

            source: Row.backgroundImage
            z:0
        }

        Rectangle {
            id: backgroundRectangle
            z:1
            y:750
            width:420
            height: 100
            color: "#eeeeee"
            opacity: 0.7
            border.width: 1
        }

        Text {
            anchors.top: backgroundRectangle.bottom
            anchors.right: backgroundRectangle.right
            font.pixelSize: 12
            text: ":AirTeam openweathermap.org"
        }

        Text {
            id: errorMsg
            z:2
            y:700
x:200
            text: "Error Data"
        }

        Item {
            id: canvas

            visible: false
            z:2
            anchors.horizontalCenter: parent.horizontalCenter
            anchors.verticalCenter: parent.verticalCenter
            width: parent.width*0.75
            height: parent.height*0.75

            Image {
                id: weatherIcon

                fillMode: Image.PreserveAspectFit
                anchors.margins: 20
                width:parent.width/2
                height:parent.height/2
                sourceSize.width:width
                sourceSize.height:height

                Timer {
                    interval: 3000; running: true; repeat: true
                    onTriggered: {
                        parent.x = Math.random()*50 - 15
                        parent.y = Math.random()*10 - 15
                    }
                }

                Behavior on x {
                    NumberAnimation { duration: 3000; easing.type: Easing.InOutSine;}
                }
                Behavior on y {
                    NumberAnimation { duration: 3000; easing.type: Easing.InOutSine;}
                }
            }

            Text {
                id: temp

                anchors.right: parent.right
                height:parent.height/4
                anchors.left: weatherIcon.right
                font.pixelSize: height
                horizontalAlignment: Text.AlignRight
            }

            Text {
                id: tempMinMax

                anchors.left: weatherIcon.right
                anchors.right: parent.right
                anchors.top: temp.bottom
                height:parent.height/20
                font.pixelSize: height
                horizontalAlignment: Text.AlignRight
            }

            Row {
                id: sunriseset

    // 			width:parent.width
                y: tempMinMax.y + tempMinMax.contentHeight
                height:parent.height/10
                anchors.right: parent.right
    // 			layoutDirection: Qt.RightToLeft

                Item {
                    id: sunRiseCanvas
                    clip:true
                    height:parent.height-10
                    width:sunRiseImg.width
    // 				anchors.right: sunRise.left

                    Image {
                        id:sunRiseImg
    // 					anchors.right: sunRise.left
        // 				anchors.verticalCenter: parent.verticalCenter

                        fillMode: Image.PreserveAspectFit
                        sourceSize.width:120
                        sourceSize.height:parent.height
                        height:parent.height

                        source: iconPath+"weather_01.svg"

                        SequentialAnimation on y {
                            loops: Animation.Infinite
                            NumberAnimation { from: 0;  to: -100; duration: 1500}
                            ScriptAction { script: sunRiseImg.y = sunRiseImg.height }
                            NumberAnimation { from: 100;  to: 0; duration: 1500}
                        }
                        SequentialAnimation on x {
                            loops: Animation.Infinite
                            NumberAnimation { from: 0;  to: 20; duration: 1500}
                            ScriptAction { script: sunRiseImg.y = -20 }
                            NumberAnimation { from: -20;  to: 0; duration: 1500}
                        }
                    }
                }

                Text {
    // 				anchors.right: sunSetCanvas.left
                    anchors.verticalCenter: parent.verticalCenter
                    id: sunRise
                    height:parent.height/2
                    font.pixelSize: height
                }

                Item {
                    width: 20
                    height: parent.height
                }

                Item {
                    id: sunSetCanvas
                    clip:true
                    height:parent.height-10
                    width:sunSetImg.width
    // 				anchors.right: sunSet.left

                    Image {
                        id:sunSetImg
    // 					anchors.right: sunSet.left
        // 				anchors.verticalCenter: parent.verticalCenter

                        fillMode: Image.PreserveAspectFit
                        sourceSize.width:100
                        sourceSize.height:parent.height
                        height:parent.height

                        source: iconPath+"weather_01.svg"

                        SequentialAnimation on y {
                            loops: Animation.Infinite
                            NumberAnimation { from: 0;  to: 100; duration: 1500}
                            ScriptAction { script: sunRiseImg.y = -sunRiseImg.height }
                            NumberAnimation { from: -100;  to: 0; duration: 1500}
                        }
                        SequentialAnimation on x {
                            loops: Animation.Infinite
                            NumberAnimation { from: 0;  to: 20; duration: 1500}
                            ScriptAction { script: sunRiseImg.y = -20 }
                            NumberAnimation { from: -20;  to: 0; duration: 1500}
                        }
                    }
                }

                Text {
                    anchors.verticalCenter: parent.verticalCenter
                    id: sunSet
                    height:parent.height/2
                    font.pixelSize: height
                }
            }

            Row {
                id: forecast

                x: 0
                z: 1
                width:parent.width
                anchors.top: sunriseset.bottom
                anchors.bottom: parent.bottom

                Repeater {
                    id: forecast_repeater
                    model: 5

                    Column {
                        width: forecast.width / 5
                        height: forecast.height
                        spacing: 5

                        Text {
                            anchors.horizontalCenter: parent.horizontalCenter
                            height: parent.height/12
                            font.pixelSize: height
                        }

                        Image {
                            width: parent.width
                            height: parent.height/2
                            fillMode: Image.PreserveAspectFit
                            anchors.horizontalCenter: parent.horizontalCenter

                            sourceSize.width: width
                            sourceSize.height: height
                        }

                        Text {
                            anchors.horizontalCenter: parent.horizontalCenter
                            horizontalAlignment: Text.AlignHCenter
                            height: parent.height/10
                            font.pixelSize: height
                        }
                    }
                }
            }
        }


            function currentStart() {
                if (currentWeather.count == 0)
                    return

                if (forecastWeather.count > 0) {
                    canvas.visible = true
                    errorMsg.visible = false
                }

                weatherIcon.source = iconPath+"weather_"+currentWeather.get(0).weatherIcon.substring(0,2)+".svg"
                temp.text = Math.round(currentWeather.get(0).temp) + "°"

                tempMinMax.text = ""
                tempMinMax.text += "Wind: "+currentWeather.get(0).windSpeedHuman + "\n"
                tempMinMax.text += "Niederschlag: "+currentWeather.get(0).precipitation+" mm"
                tempMinMax.text += "\nLuftfeuchtigkeit: "+currentWeather.get(0).humidity + "%"
                tempMinMax.text += "\nLuftdruck: "+currentWeather.get(0).pressure+" hPa"

                var d = new Date(currentWeather.get(0).sunRise)
                sunRise.text = Qt.formatDateTime(d, "hh:mm")

                var d = new Date(currentWeather.get(0).sunSet)
                sunSet.text = Qt.formatDateTime(d, "hh:mm")
            }

}
